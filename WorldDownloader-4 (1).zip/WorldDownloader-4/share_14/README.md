Copy of the main code, with 1.14 mappings.  I hope I can get rid of this, but I need it for now :|
