pub const LOG_PAGE_FAULTS: bool = false;
pub const FORCE_DISABLE_JIT: bool = false;

pub const VMWARE_HYPERVISOR_PORT: bool = true;
