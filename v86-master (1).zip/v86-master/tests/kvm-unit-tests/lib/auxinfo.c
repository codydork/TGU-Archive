#include "auxinfo.h"
struct auxinfo auxinfo = { PROGNAME };
