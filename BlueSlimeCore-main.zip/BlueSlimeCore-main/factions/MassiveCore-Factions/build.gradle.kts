dependencies {
    // Local Dependencies
    compileOnly(project(":factions:abstract"))

    // MassiveCore + Factions
    compileOnly("com.massivecraft.massivecore:MassiveCore:2.14.0")
    compileOnly("com.massivecraft.factions:Factions:2.14.0")
}
