package com.github.sirblobman.api.factions;

public final class FactionsNotFoundException extends RuntimeException {
    // Empty Class
}
