dependencies {
    compileOnly(project(":factions:abstract"))
    compileOnly("com.github.saberllc:SaberFactions:1.6.9.5-4.1.1-STABLE")
}
