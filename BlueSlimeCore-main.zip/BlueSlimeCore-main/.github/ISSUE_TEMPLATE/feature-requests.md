---
name: Feature Requests
about: Make a suggestion or submit a feature you already coded
title: ''
labels: Feature Request
assignees: ''

---

**What version of Spigot are you currently using?**
You can do `/bukkit:version` to find out

**What version of SirBlobmanCore are you using?**
You can do `/about SirBlobmanCore` to find out

**What is your feature request?**
