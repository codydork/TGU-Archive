dependencies {
    // Local Dependencies
    compileOnly(project(":nms:abstract"))

    // Spigot NMS
    compileOnly("org.spigotmc:spigot:1.8.8-R0.1-SNAPSHOT")
}
