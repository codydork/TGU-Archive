dependencies {
    // Local Dependencies
    compileOnly(project(":nms:abstract"))

    // Spigot NMS
    compileOnly("org.spigotmc:spigot:1.12.2-R0.1-SNAPSHOT")
}
