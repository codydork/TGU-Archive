dependencies {
    // Local Dependencies
    compileOnly(project(":nms:abstract"))
    compileOnly(project(":nms:modern-nbt"))

    // Spigot NMS
    compileOnly("org.spigotmc:spigot:1.16.5-R0.1-SNAPSHOT")
}
