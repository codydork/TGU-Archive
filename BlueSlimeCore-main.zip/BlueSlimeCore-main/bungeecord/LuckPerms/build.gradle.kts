dependencies {
    // Local Dependencies
    compileOnly(project(":utility"))
    compileOnly(project(":bungeecord:abstract"))

    // LuckPerms API
    compileOnly("net.luckperms:api:5.4")
}
