import {disableDevtool} from './main';

export default disableDevtool;