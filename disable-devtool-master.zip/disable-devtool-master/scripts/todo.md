<!--
 * @Author: tackchen
 * @Date: 2022-01-06 00:09:44
 * @LastEditors: tackchen
 * @LastEditTime: 2022-04-14 14:20:16
 * @FilePath: /disable-devtool/helper/todo.md
 * @Description: Coding something
-->
1. 问题：ios真机chrome 浏览器 data-to-string 和 func-to-string两个detector与开发者工具表现一致

2. Windows qq浏览器最新版本 mac safari可能会误伤 问题