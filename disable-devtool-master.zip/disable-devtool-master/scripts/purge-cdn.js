/*
 * @Author: tackchen
 * @Date: 2022-09-28 19:52:23
 * @Description: Coding something
 */
const https = require('https');

https.get(`https://purge.jsdelivr.net/npm/disable-devtool/disable-devtool.min.js`, () => {
      
});
